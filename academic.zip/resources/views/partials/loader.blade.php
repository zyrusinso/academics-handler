<div id="loading-overlay">
    <div class="loader"></div>
</div>
