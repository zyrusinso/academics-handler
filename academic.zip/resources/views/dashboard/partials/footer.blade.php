  <!-- Footer -->
  <footer id="page-footer" class="bg-body-light">
    <div class="content py-3">
        <div class="row font-size-sm">
            <div class="col-sm-6 order-sm-1 py-1 text-center text-sm-left">
                <a class="font-w600" href="{{ route('welcome') }}">Academic Handler </a> &copy; 2021 All Rights Reserved.</span>
            </div>
        </div>
    </div>
</footer>
<!-- END Footer -->
